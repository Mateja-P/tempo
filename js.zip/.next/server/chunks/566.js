"use strict";
exports.id = 566;
exports.ids = [566];
exports.modules = {

/***/ 5612:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/rightArrow.0e02a308.svg","height":800,"width":800,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 8951:
/***/ (() => {

/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/star.a888da9d.svg","height":800,"width":800,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 5022:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _public_rightArrow_svg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5612);




const Button = ({ text , bck , onClick  })=>{
    const [hovered, setHovered] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const ref = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        onMouseEnter: ()=>{
            setHovered(true);
        },
        onMouseLeave: ()=>{
            setHovered(false);
        },
        className: "inline-block relative z-[1] group/bttn cursor-pointer",
        onClick: onClick,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: `${bck} flex items-center relative border border-black z-[1] px-4 py-2`,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "nunito font-[700] mr-2 group-hover/bttn:mr-3 transition-all duration-600 ease-in",
                        children: text
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        className: "w-[20px]",
                        src: _public_rightArrow_svg__WEBPACK_IMPORTED_MODULE_3__/* ["default"].src */ .Z.src
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                ref: ref,
                className: `group-hover/bttn:top-0 transition-all duration-600 ease-in  group-hover/bttn:left-0 absolute top-[7px] left-[7px] w-full h-full border border-black z-[0] `
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Button);


/***/ }),

/***/ 5571:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

function KeyLight({ position  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rectAreaLight", {
        width: 31,
        height: 31,
        color: "#ffc9f9",
        intensity: 8,
        position: position,
        lookAt: [
            0,
            0,
            0
        ],
        penumbra: 1
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (KeyLight);


/***/ }),

/***/ 5266:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _react_three_fiber__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3784);
/* harmony import */ var _react_three_fiber__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_react_three_fiber__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var three_examples_jsm_loaders_GLTFLoader__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1217);
/* harmony import */ var maath__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9746);
/* harmony import */ var maath__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(maath__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _react_three_drei__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4165);
/* harmony import */ var _react_three_drei__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_react_three_drei__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var three__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2949);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([three__WEBPACK_IMPORTED_MODULE_5__, three_examples_jsm_loaders_GLTFLoader__WEBPACK_IMPORTED_MODULE_7__]);
([three__WEBPACK_IMPORTED_MODULE_5__, three_examples_jsm_loaders_GLTFLoader__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const M = ({ path , scale , rotation , color  })=>{
    // const gltf = useLoader(GLTFLoader, './indexMesh/M.glb');
    const gltf = (0,_react_three_fiber__WEBPACK_IMPORTED_MODULE_2__.useLoader)(three_examples_jsm_loaders_GLTFLoader__WEBPACK_IMPORTED_MODULE_7__/* .GLTFLoader */ .E, path);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_6__.useRouter)();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (color) {
            gltf.scene.children.forEach((e)=>{
                e.material.color.setColor = new three__WEBPACK_IMPORTED_MODULE_5__.Color(color);
            });
        } else {
            gltf.scene.children.forEach((e)=>{
                e.material.color = new three__WEBPACK_IMPORTED_MODULE_5__.Color("#FFFFFF");
            });
        }
        if (router.pathname === "/") {
            gltf.scene.children.forEach((e)=>{
                e.material.color = new three__WEBPACK_IMPORTED_MODULE_5__.Color("orange");
            });
        }
    }, [
        color
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CameraRig, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("primitive", {
            // scale={[0.7, 0.7, 0.7]}
            scale: scale,
            // rotation={[0.1, 0, 0]}
            rotation: rotation,
            object: gltf.scene
        })
    });
};
function CameraRig({ children  }) {
    const group = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    // const snap = useSnapshot(state);
    (0,_react_three_fiber__WEBPACK_IMPORTED_MODULE_2__.useFrame)((state, delta)=>{
        maath__WEBPACK_IMPORTED_MODULE_3__.easing.dampE(group.current.rotation, [
            state.pointer.y / 10,
            -state.pointer.x / 5,
            0
        ], 0.25, delta);
    });
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("group", {
        ref: group,
        children: children
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (M);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6061:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "H": () => (/* binding */ url)
/* harmony export */ });
const url = "http://localhost:3000/api/";


/***/ })

};
;