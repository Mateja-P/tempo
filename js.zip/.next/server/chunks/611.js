"use strict";
exports.id = 611;
exports.ids = [611];
exports.modules = {

/***/ 1611:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Jn": () => (/* binding */ changeFace),
/* harmony export */   "Oc": () => (/* binding */ removeValues),
/* harmony export */   "QX": () => (/* binding */ setActiveDecalR),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "cp": () => (/* binding */ removeDecal),
/* harmony export */   "ex": () => (/* binding */ addDecals)
/* harmony export */ });
/* unused harmony export editorSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const editorSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "editor",
    initialState: {
        face: "front",
        allDecals: [],
        activeDecalR: 0
    },
    reducers: {
        changeFace: (state, action)=>{
            state.face = action.payload;
        },
        addDecals: (state, action)=>{
            state.allDecals = [
                ...state.allDecals,
                action.payload
            ];
        },
        removeDecal: (state, action)=>{
            state.allDecals = state.allDecals.filter((e)=>{
                return e.id !== action.payload;
            });
        },
        setActiveDecalR: (state, action)=>{
            state.activeDecalR = action.payload;
        },
        removeValues: (state)=>{
            state.face = "", state.allDecals = [], state.activeDecalR = 0;
        }
    }
});
const { changeFace , addDecals , removeDecal , setActiveDecalR , removeValues  } = editorSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (editorSlice.reducer);


/***/ })

};
;