"use strict";
exports.id = 686;
exports.ids = [686];
exports.modules = {

/***/ 5154:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "io": () => (/* binding */ removeChanges),
/* harmony export */   "qN": () => (/* binding */ changeSize),
/* harmony export */   "y8": () => (/* binding */ changeGender),
/* harmony export */   "zX": () => (/* binding */ changeColor)
/* harmony export */ });
/* unused harmony export currentSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const currentSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "current",
    initialState: {
        id: undefined,
        gender: undefined,
        size: undefined,
        color: undefined,
        model: undefined,
        mQ: undefined,
        price: undefined
    },
    reducers: {
        changeGender: (state, action)=>{
            state.gender = action.payload;
        },
        changeColor: (state, action)=>{
            state.color = action.payload;
        },
        changeSize: (state, action)=>{
            state.size = action.payload;
        },
        removeChanges: (state)=>{
            state.size = undefined;
            state.color = undefined;
            state.gender = undefined;
        }
    }
});
const { changeGender , changeColor , changeSize , removeChanges  } = currentSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (currentSlice.reducer);


/***/ }),

/***/ 5623:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Components_Footer)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./public/HomePage/footerLogo.png
/* harmony default export */ const footerLogo = ({"src":"/_next/static/media/footerLogo.00aa5711.png","height":221,"width":216,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA3ElEQVR42mN4raHPxAAET62cRZ/bOOs/cXJTeGTpqPfQ3I6XAQZeqehov9A3T3hmbCPz3saW77mptcoTM3sDhAIt454XRlZBz4ysHJ/bOia9MLVJea5nofLEyJKHAQSeVjTwP/MPM37p6uX5wt4l/rmLl/UzrwCN7zduMjPAwAkGBu47DAyatxkY5O8zMGhNYWBgYQCB////R//9/dsMSBv/+/Mn+Ne7d0FAtjcQawL5Fgz//v3zBHIc/v754wqkbUBsILYDYhMQmwEIVKBYHojVgVgKytZjYGBQBgAfjmN+d5PzcQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./Components/Footer.js



const Footer = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "bg-dark text-white py-7",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex w-[70%] items-center mx-auto my-0 justify-between lg:w-[90%] md:w-[97%] sm:flex-col sm:items-start",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "montserrat sm:my-3",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            className: "w-[85px]",
                            src: footerLogo.src
                        }),
                        " "
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "sm:my-3",
                    children: "+381 62 843 18 54"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    target: "_blank",
                    className: "sm:my-3",
                    href: "https://mail.google.com/mail/u/5/#inbox?compose=GTvVlcRwQZjvVhhKZbpNKKVKmWztkRXZqxZMfHnMXkNsBwzLWkKkXVpzJbLqsLdkclQqHjRgGKGbg",
                    children: "buzzmall.contact@gmail.com"
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            target: "_blank",
                            className: "block my-3",
                            href: "https://www.facebook.com/profile.php?id=100092751109099&is_tour_dismissed=true",
                            children: "Facebook"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            target: "_blank",
                            className: "block",
                            href: "https://www.instagram.com/buzzmall.co/",
                            children: "Instagram"
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const Components_Footer = (Footer);


/***/ }),

/***/ 9702:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _public_cart_svg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7586);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _Cart__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9695);
/* harmony import */ var _public_HomePage_logo_png__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8655);







const Header = ()=>{
    const [openMenu, setOpenMenu] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [sticky, setSticky] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const headerRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        window.addEventListener("scroll", ()=>{
            if (window.scrollY < 1) {
                setSticky(true);
            } else {
                setSticky(false);
            }
        });
    }, [
        sticky
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        ref: headerRef,
        className: `${sticky ? "bg-[#ffffff36]" : "bg-[#fff] py-4"} py-3 fixed w-full z-[999] transition-all duration-600 ease-in`,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex justify-between w-[80%] my-0 mx-auto items-center z-[999] md:w-[97%]",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "z-[999] sm:w-[100px] xs:w-[85px]",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        className: "w-[75px]",
                        src: _public_HomePage_logo_png__WEBPACK_IMPORTED_MODULE_6__/* ["default"].src */ .Z.src
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: `flex gap-8 md:absolute transition-all duration-300 ease-in ${openMenu ? "md:top-full" : "md:top-[-300%]"} 
           md:flex-col md:bg-primary md:justify-center md:items-end md:pr-3 md:w-[97%] md:py-7 `,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                            className: `montserrat text-[15px] 2xl:text-[13px] md:text-[16px] sm:text-[16px] md:border-b md:border-black md:px-3 md:py-2 ${sticky ? "font-[500]" : "font-[600]"}`,
                            href: "/",
                            children: "Pocetna"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                            className: `montserrat text-[15px] 2xl:text-[13px] md:text-[16px] font-[400] sm:text-[16px] md:border-b md:border-black md:px-3 md:py-2 ${sticky ? "font-[500]" : "font-[600]"}`,
                            href: "/proizvodi",
                            children: "Proizvodi"
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Cart__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                    divStyle: "z-[999]",
                    imgStyle: "w-[40px] 2xl:w-[35px] cursor-pointer"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: `hidden md:flex md:flex-col md:justify-between md:w-5 md:h-5 transition-all duration-600 ease-in md:z-[999]`,
                    onClick: ()=>setOpenMenu(!openMenu),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: `w-full h-0.5 bg-black transition-all duration-600 ease-in ${openMenu ? "rotate-[-45deg] translate-y-[9px] bg-black" : ""}`
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: `w-full h-0.5 translate-x-1 bg-black transition-all duration-600 ease-in ${openMenu ? "opacity-0" : ""}`
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: `w-full h-0.5 bg-black transition-all duration-600 ease-in ${openMenu ? "rotate-45 translate-y-[-9px] bg-black" : ""}`
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Header);


/***/ })

};
;