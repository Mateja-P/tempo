"use strict";
exports.id = 346;
exports.ids = [346];
exports.modules = {

/***/ 6346:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PD": () => (/* binding */ changeTotal),
/* harmony export */   "VC": () => (/* binding */ addProductInCart),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "cl": () => (/* binding */ removeItem)
/* harmony export */ });
/* unused harmony export cartSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const cartSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "cart",
    initialState: {
        items: []
    },
    reducers: {
        addProductInCart: (state, action)=>{
            state.items = [
                ...state.items,
                action.payload
            ];
        },
        removeItem: (state, action)=>{
            state.items = state.items.filter((e)=>{
                return e.id !== action.payload;
            });
        },
        changeTotal: (state, action)=>{
            state.items = state.items.map((item)=>{
                if (item.id === action.payload.id) {
                    return {
                        ...item,
                        total: action.payload.price && action.payload.quantity ? action.payload.price * action.payload.quantity : action.payload.price,
                        quantity: action.payload.quantity
                    };
                } else {
                    return item;
                }
            });
        }
    }
});
const { addProductInCart , removeItem , changeTotal  } = cartSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (cartSlice.reducer);


/***/ })

};
;