"use strict";
(() => {
var exports = {};
exports.id = 304;
exports.ids = [304];
exports.modules = {

/***/ 2744:
/***/ ((module) => {

module.exports = require("mysql");

/***/ }),

/***/ 1027:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "K": () => (/* binding */ credentials)
/* harmony export */ });
const credentials = {
    host: "localhost",
    user: "root",
    password: "",
    database: "3601"
};


/***/ }),

/***/ 2052:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ id)
/* harmony export */ });
/* harmony import */ var _Credentials_dbCredentials__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1027);
const mysql = __webpack_require__(2744);

const db = mysql.createConnection({
    host: _Credentials_dbCredentials__WEBPACK_IMPORTED_MODULE_0__/* .credentials.host */ .K.host,
    user: _Credentials_dbCredentials__WEBPACK_IMPORTED_MODULE_0__/* .credentials.user */ .K.user,
    password: _Credentials_dbCredentials__WEBPACK_IMPORTED_MODULE_0__/* .credentials.password */ .K.password,
    database: _Credentials_dbCredentials__WEBPACK_IMPORTED_MODULE_0__/* .credentials.database */ .K.database
});
function id(req, res) {
    const { id  } = req.query;
    //   const q = `SELECT defaultProducts.*, subproducts.id as subId, subproducts.modelName, subproducts.model, subproducts.price, subproducts.discountPrice, subproducts.defaultProducts_id, subproducts.information, productsproperties.properties, faces.faces FROM defaultProducts inner join subproducts on defaultProducts.id = subproducts.defaultProducts_id inner join productsproperties on subproducts.id = productsproperties.subProducts_id inner join faces on subproducts.id = faces.subProducts_id WHERE subproducts.id = ${id}`;
    const q = `SELECT products.*, properties.properties FROM products INNER JOIN properties ON properties.products_id = products.id WHERE products.id = ${id}`;
    db.query(q, (error, data)=>{
        return res.json(data);
    });
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(2052));
module.exports = __webpack_exports__;

})();