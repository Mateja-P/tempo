"use strict";
(() => {
var exports = {};
exports.id = 957;
exports.ids = [957];
exports.modules = {

/***/ 2744:
/***/ ((module) => {

module.exports = require("mysql");

/***/ }),

/***/ 1027:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "K": () => (/* binding */ credentials)
/* harmony export */ });
const credentials = {
    host: "localhost",
    user: "root",
    password: "",
    database: "3601"
};


/***/ }),

/***/ 1412:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ categories)
/* harmony export */ });
/* harmony import */ var _Credentials_dbCredentials__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1027);
const mysql = __webpack_require__(2744);

const db = mysql.createConnection({
    host: _Credentials_dbCredentials__WEBPACK_IMPORTED_MODULE_0__/* .credentials.host */ .K.host,
    user: _Credentials_dbCredentials__WEBPACK_IMPORTED_MODULE_0__/* .credentials.user */ .K.user,
    password: _Credentials_dbCredentials__WEBPACK_IMPORTED_MODULE_0__/* .credentials.password */ .K.password,
    database: _Credentials_dbCredentials__WEBPACK_IMPORTED_MODULE_0__/* .credentials.database */ .K.database
});
function categories(req, res) {
    const q = "SELECT * FROM categories";
    db.query(q, (error, data)=>{
        return res.json(data);
    });
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(1412));
module.exports = __webpack_exports__;

})();