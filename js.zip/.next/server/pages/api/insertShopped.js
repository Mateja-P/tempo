"use strict";
(() => {
var exports = {};
exports.id = 160;
exports.ids = [160];
exports.modules = {

/***/ 2744:
/***/ ((module) => {

module.exports = require("mysql");

/***/ }),

/***/ 1027:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "K": () => (/* binding */ credentials)
/* harmony export */ });
const credentials = {
    host: "localhost",
    user: "root",
    password: "",
    database: "3601"
};


/***/ }),

/***/ 5878:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "config": () => (/* binding */ config),
/* harmony export */   "default": () => (/* binding */ products)
/* harmony export */ });
/* harmony import */ var _Credentials_dbCredentials__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1027);
const mysql = __webpack_require__(2744);

const db = mysql.createConnection({
    host: _Credentials_dbCredentials__WEBPACK_IMPORTED_MODULE_0__/* .credentials.host */ .K.host,
    user: _Credentials_dbCredentials__WEBPACK_IMPORTED_MODULE_0__/* .credentials.user */ .K.user,
    password: _Credentials_dbCredentials__WEBPACK_IMPORTED_MODULE_0__/* .credentials.password */ .K.password,
    database: _Credentials_dbCredentials__WEBPACK_IMPORTED_MODULE_0__/* .credentials.database */ .K.database
});
const config = {
    api: {
        bodyParser: {
            sizeLimit: "300mb"
        }
    }
};
function products(req, res) {
    const { ime  } = req.body.sendData;
    const { prezime  } = req.body.sendData;
    const { adresa  } = req.body.sendData;
    const { ipAdress  } = req.body.sendData;
    const { phone  } = req.body.sendData;
    const { email  } = req.body.sendData;
    const { napomena  } = req.body.sendData;
    // const { total } = req.body.sendData;
    const productsJson = {
        properties: req.body.products
    };
    const sendProductsJson = JSON.stringify(productsJson);
    const containsNumbers = (str)=>{
        return /\d/.test(str);
    };
    const containsStrings = (num)=>{
        return /^\d*\.?\d*$/.test(num);
    };
    const products = productsJson.properties.map(({ ...item })=>item);
    const p = JSON.stringify(products);
    let total = 0;
    req.body.products.forEach((e)=>{
        total += Number(e.total);
    });
    if (ime !== "" && prezime !== "" && adresa !== "" && ipAdress !== "" && phone !== "" && email !== "") {
        //ime, prezime, kod, telefon, email.
        if (!containsNumbers(ime) && !containsNumbers(prezime)) {
            if (containsStrings(phone) && containsStrings(ipAdress)) {
                const q = `INSERT INTO shopped (ime, postalCode, adress, phone, email, note, products, confirmed, payed) VALUES ('${ime + " " + prezime}', '${ipAdress}', '${adresa}', '${phone}', '${email}', '${napomena}', '${p}', 0, ${total})`;
                // }', '${ipAdress}', '${adresa}', '${phone}', '${email}', '${napomena}', '${sendProductsJson}', 0, ${total})`;
                db.query(q, (error, data)=>{
                    if (error) {
                        console.log(error);
                    } else {
                        return res.send({
                            type: "success",
                            mess: "Uspesno ste porucili"
                        });
                    }
                });
            } else {
                res.send({
                    type: "error",
                    mess: "Telefon i postanski kod mogu imati samo brojeve bez razmaka"
                });
            }
        } else {
            res.send({
                type: "error",
                mess: "Ime i prezime mogu imati samo slova"
            });
        }
    } else {
        res.send({
            type: "error",
            mess: "Sva polja su obavezna sem napomene"
        });
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(5878));
module.exports = __webpack_exports__;

})();