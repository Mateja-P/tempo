"use strict";
(() => {
var exports = {};
exports.id = 491;
exports.ids = [491];
exports.modules = {

/***/ 2744:
/***/ ((module) => {

module.exports = require("mysql");

/***/ }),

/***/ 1027:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "K": () => (/* binding */ credentials)
/* harmony export */ });
const credentials = {
    host: "localhost",
    user: "root",
    password: "",
    database: "3601"
};


/***/ }),

/***/ 1010:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ show)
/* harmony export */ });
/* harmony import */ var _Credentials_dbCredentials__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1027);
// Next.js API route support: https://nextjs.org/docs/api-routes/introduction
// import { mysql } from 'mysql';
const mysql = __webpack_require__(2744);

const db = mysql.createConnection({
    host: _Credentials_dbCredentials__WEBPACK_IMPORTED_MODULE_0__/* .credentials.host */ .K.host,
    user: _Credentials_dbCredentials__WEBPACK_IMPORTED_MODULE_0__/* .credentials.user */ .K.user,
    password: _Credentials_dbCredentials__WEBPACK_IMPORTED_MODULE_0__/* .credentials.password */ .K.password,
    database: _Credentials_dbCredentials__WEBPACK_IMPORTED_MODULE_0__/* .credentials.database */ .K.database
});
function show(req, res) {
    const q = "SELECT * FROM shopped ORDER by id DESC";
    db.query(q, (error, data)=>{
        return res.json(data);
    });
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(1010));
module.exports = __webpack_exports__;

})();