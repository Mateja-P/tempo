(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 5154:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "io": () => (/* binding */ removeChanges),
/* harmony export */   "qN": () => (/* binding */ changeSize),
/* harmony export */   "y8": () => (/* binding */ changeGender),
/* harmony export */   "zX": () => (/* binding */ changeColor)
/* harmony export */ });
/* unused harmony export currentSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const currentSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "current",
    initialState: {
        id: undefined,
        gender: undefined,
        size: undefined,
        color: undefined,
        model: undefined,
        mQ: undefined,
        price: undefined
    },
    reducers: {
        changeGender: (state, action)=>{
            state.gender = action.payload;
        },
        changeColor: (state, action)=>{
            state.color = action.payload;
        },
        changeSize: (state, action)=>{
            state.size = action.payload;
        },
        removeChanges: (state)=>{
            state.size = undefined;
            state.color = undefined;
            state.gender = undefined;
        }
    }
});
const { changeGender , changeColor , changeSize , removeChanges  } = currentSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (currentSlice.reducer);


/***/ }),

/***/ 1741:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ App)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./styles/globals.css
var globals = __webpack_require__(6764);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: external "@reduxjs/toolkit"
var toolkit_ = __webpack_require__(5184);
// EXTERNAL MODULE: ./Components/Context/currentRedux.js
var currentRedux = __webpack_require__(5154);
// EXTERNAL MODULE: ./Components/Context/cartRedux.js
var cartRedux = __webpack_require__(6346);
// EXTERNAL MODULE: ./Components/Context/editorRedux.js
var editorRedux = __webpack_require__(1611);
;// CONCATENATED MODULE: external "redux-thunk"
const external_redux_thunk_namespaceObject = require("redux-thunk");
var external_redux_thunk_default = /*#__PURE__*/__webpack_require__.n(external_redux_thunk_namespaceObject);
;// CONCATENATED MODULE: ./pages/_app.js








const store = (0,toolkit_.configureStore)({
    middleware: [
        (external_redux_thunk_default())
    ],
    reducer: {
        currentProduct: currentRedux/* default */.ZP,
        cartProducts: cartRedux/* default */.ZP,
        editor: editorRedux/* default */.ZP
    }
});
function App({ Component , pageProps  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx(external_react_redux_.Provider, {
        store: store,
        children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
            ...pageProps
        })
    });
}


/***/ }),

/***/ 6764:
/***/ (() => {



/***/ }),

/***/ 5184:
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 6022:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [346,611], () => (__webpack_exec__(1741)));
module.exports = __webpack_exports__;

})();