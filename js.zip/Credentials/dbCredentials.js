export const credentials = {
  host: 'http://buzzmall.a2hosted.com/',
  user: 'buzzmall_360_first_database',
  password: 'qJb9iszcWDFyxdx',
  database: 'buzzmall_360',
};
