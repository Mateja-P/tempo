export const url = 'http://buzzmall.a2hosted.com/api/';
