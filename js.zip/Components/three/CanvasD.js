import { Canvas } from '@react-three/fiber';

const CanvasD = ({ children }) => {
  return <Canvas>{children}</Canvas>;
};

export default CanvasD;
