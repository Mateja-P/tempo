import React from 'react';

const MobileFaces = () => {
  return <div>MobileFaces</div>;
};

export default MobileFaces;
